<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Landing pages (Orient Yemen)
|--------------------------------------------------------------------------
| Arabic: /
| English: /en
*/

Route::name('site.')->group(function () {
    Route::view('/', 'site.home')->name('home');

    Route::view('/about', 'site.pages.about.index')->name('about');
    Route::view('/contact', 'site.pages.contact.index')->name('contact');
    Route::view('/partners', 'site.pages.partners.index')->name('partners');
    Route::view('/products', 'site.pages.products.index')->name('products');
    Route::view('/products/sweets', 'site.pages.products.sweets.index')->name('products_sweets');
    Route::view('/products/coffee', 'site.pages.products.coffee.index')->name('products_coffee');
});

Route::prefix('en')->name('site_en.')->group(function () {
    Route::view('/', 'site-en.home')->name('home');

    Route::view('/about', 'site-en.pages.about.index')->name('about');
    Route::view('/contact', 'site-en.pages.contact.index')->name('contact');
    Route::view('/partners', 'site-en.pages.partners.index')->name('partners');
    Route::view('/products', 'site-en.pages.products.index')->name('products');
    Route::view('/products/sweets', 'site-en.pages.products.sweets.index')->name('products_sweets');
});

/*
|--------------------------------------------------------------------------
| Legacy URL redirects (from static HTML structure)
|--------------------------------------------------------------------------
*/
Route::redirect('/index.html', '/');
Route::redirect('/index_en.html', '/en');

Route::redirect('/pages/about/index.html', '/about');
Route::redirect('/pages/contact/index.html', '/contact');
Route::redirect('/pages/partners/index.html', '/partners');
Route::redirect('/pages/products/index.html', '/products');
Route::redirect('/pages/products/sweets/index.html', '/products/sweets');

Route::redirect('/pages_en/about/index.html', '/en/about');
Route::redirect('/pages_en/contact/index.html', '/en/contact');
Route::redirect('/pages_en/partners/index.html', '/en/partners');
Route::redirect('/pages_en/products/index.html', '/en/products');
Route::redirect('/pages_en/products/sweets/index.html', '/en/products/sweets');
