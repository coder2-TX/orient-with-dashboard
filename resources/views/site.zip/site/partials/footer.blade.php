<footer class="oy-footer" id="footer" role="contentinfo">
  @php
    $footer = \App\Models\HomeFooter::query()
      ->where('is_active', true)
      ->latest('id')
      ->first();

    $email = $footer?->email ?? 'info@orientyemen.com';

    // ✅ تنظيف البريد من المسافات/الأسطر الجديدة
    $emailClean = preg_replace('/\s+/', '', trim((string) $email));
    if ($emailClean === '') {
      $emailClean = 'info@orientyemen.com';
    }

    $phone = $footer?->phone ?? '+967 734888880';

    $locationText = $footer?->location_text_ar ?? 'Somewhere in the World';
    $locationUrl  = $footer?->location_url;

    $locations = $footer?->locations;
    if (!is_array($locations)) {
      $locations = [
        ['name_ar' => 'اليمن', 'name_en' => 'Yemen'],
        ['name_ar' => 'المملكة العربية السعودية', 'name_en' => 'Saudi Arabia'],
        ['name_ar' => 'إندونيسيا', 'name_en' => 'Indonesia'],
      ];
    }

    $xUrl        = $footer?->x_url;
    $facebookUrl = $footer?->facebook_url;
    $whatsappUrl = $footer?->whatsapp_url;
  @endphp

  <div class="oy-footer__inner">
    <div class="oy-footer__top">
      <div class="oy-footer__left">
        <div class="oy-footer__col" id="contact">
          <div class="oy-footer__brand">
            <img class="oy-footer__logo" src="assets/images/header/logo_white.svg" alt="Orient Yemen">
          </div>

          <div class="oy-footer__contact">
            <div class="oy-footer__contact-item">
              <i class="fa-solid fa-envelope oy-footer__contact-icon" aria-hidden="true"></i>

              <a class="oy-footer__contact-value"
                 href="https://mail.google.com/mail/?view=cm&fs=1&to={{ urlencode($emailClean) }}"
                 target="_blank" rel="noopener noreferrer">
                {{ $emailClean }}
              </a>
            </div>

            <div class="oy-footer__contact-item">
              <i class="fa-solid fa-phone oy-footer__contact-icon" aria-hidden="true"></i>
              @php
                $tel = preg_replace('/\s+/', '', $phone);
              @endphp
              <a class="oy-footer__contact-value" href="tel:{{ $tel }}">{{ $phone }}</a>
            </div>

            <div class="oy-footer__contact-item">
              <i class="fa-solid fa-location-dot oy-footer__contact-icon" aria-hidden="true"></i>

              @if($locationUrl)
                <a class="oy-footer__contact-value" href="{{ $locationUrl }}" target="_blank" rel="noopener noreferrer">
                  {{ $locationText }}
                </a>
              @else
                <span class="oy-footer__contact-value">{{ $locationText }}</span>
              @endif
            </div>
          </div>
        </div>

        <div class="oy-footer__col oy-footer__centered oy-footer__quick">
          <div class="oy-footer__heading oy-footer__heading--center">روابط سريعة</div>
          <ul class="oy-footer__list oy-footer__list--center">
            <li><a class="oy-footer__link" href="{{ route('site.home') }}">الرئيسية</a></li>
            <li><a class="oy-footer__link" href="{{ route('site.about') }}">من نحن</a></li>
            <li><a class="oy-footer__link" href="{{ route('site.products') }}">منتجاتنا</a></li>
            <li><a class="oy-footer__link" href="{{ route('site.partners') }}">شركائنا</a></li>
            <li><a class="oy-footer__link" href="{{ route('site.contact') }}">تواصل معنا</a></li>
          </ul>
        </div>

        <div class="oy-footer__col oy-footer__centered oy-footer__locations">
          <div class="oy-footer__heading oy-footer__heading--center">مواقعـــنا</div>
          <ul class="oy-footer__list oy-footer__list--center">
            @foreach($locations as $loc)
              @php $nameAr = $loc['name_ar'] ?? null; @endphp
              @if($nameAr)
                <li>{{ $nameAr }}</li>
              @endif
            @endforeach
          </ul>
        </div>
      </div>

      <div class="oy-footer__right">
        <div class="oy-footer__col oy-footer__social">
          <div class="oy-footer__heading oy-footer__heading--center">مواقعنا على السوشل ميديا</div>

          <div class="oy-footer__socials">
            <a class="oy-footer__social-btn" href="{{ $xUrl ?: '#' }}" aria-label="X (Twitter)"
               @if($xUrl) target="_blank" rel="noopener noreferrer" @endif>
              <i class="fa-brands fa-x-twitter"></i>
            </a>

            <a class="oy-footer__social-btn" href="{{ $facebookUrl ?: '#' }}" aria-label="Facebook"
               @if($facebookUrl) target="_blank" rel="noopener noreferrer" @endif>
              <i class="fa-brands fa-facebook-f"></i>
            </a>

            <a class="oy-footer__social-btn" href="{{ $whatsappUrl ?: '#' }}" aria-label="WhatsApp"
               @if($whatsappUrl) target="_blank" rel="noopener noreferrer" @endif>
              <i class="fa-brands fa-whatsapp"></i>
            </a>
          </div>
        </div>
      </div>
    </div>

    <div class="oy-footer__divider" aria-hidden="true"></div>

    <div class="oy-footer__bottom">
      <div>All rights reserved to orient yemen for import</div>
      <div>
        Powered by
        <a class="oy-footer__bottom-link" href="https://destination-media.pro/" target="_blank" rel="noopener noreferrer">
          <strong>Destination Media</strong>
        </a>
      </div>
    </div>
  </div>
</footer>
