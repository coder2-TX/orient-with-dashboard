<!-- pages/products/index.html -->
<!-- ORIENT YEMEN - Products Page -->

<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Important: makes all relative URLs resolve from project root -->
  <base href="../../">

  <title>منتجاتنا | Orient Yemen</title>

  <!-- Icons (optional but consistent with project) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

  <!-- Global tokens first -->
  <link rel="stylesheet" href="assets/css/tokens.css">
  <link rel="stylesheet" href="assets/css/global.css">

  <!-- Shared styles -->
  <link rel="stylesheet" href="assets/css/header.css">
  <link rel="stylesheet" href="assets/css/about.css">
  <link rel="stylesheet" href="assets/css/footer.css">

  <!-- Products page hero -->
  <link rel="stylesheet" href="assets/css/pages/products/hero.css">

  <!-- Products section 2 -->
  <link rel="stylesheet" href="assets/css/pages/products/section2.css">

  <!-- Shared scripts -->
  <script src="assets/js/header.js" defer></script>

  <!-- Products page loader -->
  <script src="assets/js/pages/products.js" defer></script>
</head>

<body>
  <div id="header-slot"></div>

  <!-- Products Hero -->
  <div id="hero-slot"></div>

  <!-- Section 2: Tabs + Intro -->
  <div id="section2-slot"></div>

  <div id="footer-slot"></div>
</body>
</html>
