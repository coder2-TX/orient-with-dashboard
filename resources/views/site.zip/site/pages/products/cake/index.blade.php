<!-- pages/products/cake/index.html -->
<!-- ORIENT YEMEN - Cakes Products Page -->

<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Important: makes all relative URLs resolve from project root -->
  <base href="../../../">

  <title>الكيك | Orient Yemen</title>

  <!-- Icons (optional but consistent with project) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

  <!-- Global tokens first -->
  <link rel="stylesheet" href="assets/css/tokens.css">
  <link rel="stylesheet" href="assets/css/global.css">

  <!-- Shared styles -->
  <link rel="stylesheet" href="assets/css/header.css">
  <link rel="stylesheet" href="assets/css/about.css">
  <link rel="stylesheet" href="assets/css/footer.css">

  <!-- Products page hero (reuse same hero) -->
  <link rel="stylesheet" href="assets/css/pages/products/hero.css">

  <!-- Tabs base styles -->
  <link rel="stylesheet" href="assets/css/pages/products/section2.css">

  <!-- Cakes page section -->
  <link rel="stylesheet" href="assets/css/pages/products/cake/section2.css">

  <!-- Shared scripts -->
  <script src="assets/js/header.js" defer></script>

  <!--  GSAP -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js" defer></script>

  <!-- Cakes page loader -->
  <script src="assets/js/pages/products-cake.js" defer></script>
</head>

<body>
  <div id="header-slot"></div>

  <!-- Products Hero -->
  <div id="hero-slot"></div>

  <!-- Cakes Section -->
  <div id="section2-slot"></div>

  <div id="footer-slot"></div>
</body>
</html>