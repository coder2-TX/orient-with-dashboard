<!-- pages/about/partials/section-2.html -->
<!-- ORIENT YEMEN - About section (guaranteed same typography as Home About text) -->

<section class="oy-section oy-about oy-about-page" id="about" aria-label="About Orient Yemen">
  <div class="oy-section__inner">
    <div class="oy-about__content">

      <h2 class="oy-section__title oy-reveal oy-delay-1">
        <span class="oy-section__title-icon" aria-hidden="true"></span>
        <span>عن أورينت يمن</span>
      </h2>

      <p class="oy-section__text oy-about-page__lead oy-reveal oy-delay-2">
        أورينت يمن شركة تعمل في مجال استيراد وتسويق المنتجات
      </p>

      <p class="oy-section__text oy-reveal oy-delay-3">
        تأسست عام 2007، وتركّز على بناء حضور تجاري منظّم ومستدام للعلامات التجارية عبر أسواق متعددة.
      </p>

      <p class="oy-section__text oy-reveal oy-delay-4">
        منذ انطلاقتها، اعتمدت الشركة على نهج واضح يقوم على فهم طبيعة الأسواق، وبناء علاقات طويلة الأمد مع الموردين والشركاء،
        وتقديم حلول عملية تربط المنتجات بالأسواق المستهدفة بكفاءة واستقرار.
      </p>

      <div class="oy-about-page__branches oy-reveal oy-delay-5" aria-label="Company Branches">
        <div class="oy-about-page__branches-row">
          <span class="oy-about-page__branches-label">عبر فروعها</span>

          <span class="oy-about-page__branches-items">
            <span class="oy-about-page__branch">
              <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
              <span>اليمن</span>
            </span>

            <span class="oy-about-page__branch">
              <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
              <span>المملكة العربية السعودية</span>
            </span>

            <span class="oy-about-page__branch">
              <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
              <span>إندونيسيا</span>
            </span>
          </span>
        </div>
      </div>

      <p class="oy-section__text oy-about-page__closing oy-reveal oy-delay-6">
        ما يمنحها قدرة أكبر على إدارة الأعمال ضمن نطاق جغرافي متنوع، وفهم اختلاف متطلبات كل سوق، والتعامل بمرونة مع سلاسل التوريد والتسويق.
      </p>

    </div>
  </div>

  <div class="oy-about__pattern" aria-hidden="true"></div>
</section>
